package com.example.adblock

object DnsUtil {
    class Question(val name: String, val end: Int)

    /** Разбирает имя из первого вопроса DNS-запроса. dns — только DNS-часть пакета. */
    fun parse(dns: ByteArray): Question? {
        if (dns.size < 17) return null
        var p = 12
        val sb = StringBuilder()
        while (p < dns.size) {
            val len = dns[p].toInt() and 0xFF
            if (len == 0) return if (p + 5 <= dns.size) Question(sb.toString().lowercase(), p + 5) else null
            if (len and 0xC0 != 0) return null
            p++
            if (p + len > dns.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(dns, p, len, Charsets.US_ASCII))
            p += len
        }
        return null
    }

    /** Ответ NXDOMAIN: «такого домена нет». */
    fun nxdomain(dns: ByteArray, q: Question): ByteArray {
        val r = dns.copyOf(q.end)
        r[2] = (r[2].toInt() or 0x80).toByte() // QR = ответ
        r[3] = 0x83.toByte()                   // RA + RCODE=3
        for (i in 6..11) r[i] = 0              // нет answer/authority/additional
        return r
    }

    private fun put16(b: ByteArray, off: Int, v: Int) {
        b[off] = (v shr 8).toByte(); b[off + 1] = v.toByte()
    }

    private fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0
        var i = off
        while (i < off + len) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    /** Собирает IPv4/UDP-пакет-ответ на запрос req (ihl — длина IP-заголовка). */
    fun buildResponse(req: ByteArray, ihl: Int, payload: ByteArray): ByteArray {
        val total = ihl + 8 + payload.size
        val r = ByteArray(total)
        System.arraycopy(req, 0, r, 0, ihl + 8)
        System.arraycopy(req, 12, r, 16, 4)       // src <- dst
        System.arraycopy(req, 16, r, 12, 4)       // dst <- src
        r[ihl] = req[ihl + 2]; r[ihl + 1] = req[ihl + 3]
        r[ihl + 2] = req[ihl]; r[ihl + 3] = req[ihl + 1]
        put16(r, 2, total)
        r[8] = 64
        put16(r, 10, 0)
        put16(r, 10, checksum(r, 0, ihl))
        put16(r, ihl + 4, 8 + payload.size)
        put16(r, ihl + 6, 0)                       // UDP checksum не обязателен в IPv4
        System.arraycopy(payload, 0, r, ihl + 8, payload.size)
        return r
    }
}
