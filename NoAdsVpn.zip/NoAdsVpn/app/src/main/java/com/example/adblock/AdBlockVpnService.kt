package com.example.adblock

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * Локальный VPN: в него попадают только DNS-запросы (к фейковому DNS и к популярным
 * публичным DNS, на которые приложения ходят в обход системных настроек).
 * Рекламные домены получают NXDOMAIN, остальное пересылается на настоящий DNS.
 */
class AdBlockVpnService : VpnService() {
    companion object {
        const val ACTION_STOP = "com.example.adblock.STOP"
        const val ACTION_RELOAD = "com.example.adblock.RELOAD"
        @Volatile var running = false
        @Volatile var blockedCount = 0
        @Volatile var listSize = 0
        private const val FAKE_DNS = "10.111.222.2"
        private const val UPSTREAM = "1.1.1.1"
        private val HARDCODED_DNS = listOf(
            "8.8.8.8", "8.8.4.4", "1.1.1.1", "1.0.0.1", "9.9.9.9",
            "149.112.112.112", "208.67.222.222", "208.67.220.220",
            "94.140.14.14", "94.140.15.15"
        )
    }

    private var tun: ParcelFileDescriptor? = null
    private val pool = Executors.newFixedThreadPool(8)
    @Volatile private var blocked: Set<String> = emptySet()
    private val upstream: InetAddress = InetAddress.getByName(UPSTREAM)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopVpn(); return START_NOT_STICKY }
            ACTION_RELOAD -> {
                if (running) { reload(); return START_STICKY }
                return START_NOT_STICKY
            }
        }
        if (!running) startVpn()
        return START_STICKY
    }

    private fun reload() {
        blocked = BlockList.load(this)
        listSize = blocked.size
    }

    private fun startVpn() {
        reload()
        blockedCount = 0
        val b = Builder()
            .setSession("AdBlock VPN")
            .addAddress("10.111.222.1", 24)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .setBlocking(true)
        for (ip in HARDCODED_DNS) b.addRoute(ip, 32)
        tun = b.establish() ?: return
        running = true
        Thread { loop() }.start()
    }

    private fun stopVpn() {
        running = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        pool.shutdownNow()
        super.onDestroy()
    }

    private fun isBlocked(name: String): Boolean {
        val set = blocked
        var d = name
        while (true) {
            if (d in set) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }

    private fun loop() {
        val fd = tun?.fileDescriptor ?: return
        val input = FileInputStream(fd)
        val output = FileOutputStream(fd)
        val buf = ByteArray(32767)
        try {
            while (running) {
                val n = input.read(buf)
                if (n > 0) handle(buf.copyOf(n), output)
            }
        } catch (_: Exception) {
        } finally {
            running = false
        }
    }

    private fun handle(pkt: ByteArray, out: FileOutputStream) {
        if (pkt.size < 28 || (pkt[0].toInt() shr 4) != 4) return
        val ihl = (pkt[0].toInt() and 0x0F) * 4
        if (pkt[9].toInt() != 17) return                                   // только UDP
        val dstPort = ((pkt[ihl + 2].toInt() and 0xFF) shl 8) or (pkt[ihl + 3].toInt() and 0xFF)
        if (dstPort != 53) return
        val dns = pkt.copyOfRange(ihl + 8, pkt.size)
        val q = DnsUtil.parse(dns) ?: return

        if (isBlocked(q.name)) {
            blockedCount++
            write(out, DnsUtil.buildResponse(pkt, ihl, DnsUtil.nxdomain(dns, q)))
            return
        }
        pool.execute {
            try {
                DatagramSocket().use { s ->
                    protect(s)                                               // в обход VPN
                    s.soTimeout = 4000
                    s.send(DatagramPacket(dns, dns.size, upstream, 53))
                    val rb = ByteArray(4096)
                    val rp = DatagramPacket(rb, rb.size)
                    s.receive(rp)
                    write(out, DnsUtil.buildResponse(pkt, ihl, rb.copyOf(rp.length)))
                }
            } catch (_: Exception) {}
        }
    }

    private fun write(out: FileOutputStream, data: ByteArray) {
        synchronized(out) { try { out.write(data) } catch (_: Exception) {} }
    }
}
