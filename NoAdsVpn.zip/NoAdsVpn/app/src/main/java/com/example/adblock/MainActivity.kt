package com.example.adblock

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var counter: TextView
    private lateinit var button: Button
    private lateinit var update: Button

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            status.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        status = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER }
        counter = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 16, 0, 32) }
        button = Button(this).apply { setOnClickListener { toggle() } }
        update = Button(this).apply {
            text = "Обновить списки блокировки"
            setOnClickListener { updateLists() }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            addView(status); addView(counter); addView(button); addView(update)
        })
    }

    override fun onResume() { super.onResume(); ticker.run() }
    override fun onPause() { super.onPause(); status.removeCallbacks(ticker) }

    private fun refresh() {
        val on = AdBlockVpnService.running
        status.text = if (on) "Блокировка включена" else "Блокировка выключена"
        counter.text = if (on)
            "Заблокировано запросов: ${AdBlockVpnService.blockedCount}\nДоменов в списке: ${AdBlockVpnService.listSize}"
        else ""
        button.text = if (on) "Выключить" else "Включить"
    }

    private fun toggle() {
        if (AdBlockVpnService.running) {
            startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP))
        } else {
            val intent = VpnService.prepare(this)
            if (intent != null) startActivityForResult(intent, 1) else startVpn()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1 && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        startService(Intent(this, AdBlockVpnService::class.java))
    }

    private fun updateLists() {
        update.isEnabled = false
        update.text = "Загрузка…"
        Thread {
            val n = BlockList.update(this)
            runOnUiThread {
                update.isEnabled = true
                update.text = "Обновить списки блокировки"
                val msg = if (n < 0) "Не удалось скачать списки" else "Загружено доменов: $n"
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                if (n > 0 && AdBlockVpnService.running) {
                    startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_RELOAD))
                }
            }
        }.start()
    }
}
