package com.example.adblock

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object BlockList {
    private val URLS = listOf(
        "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
        "https://adaway.org/hosts.txt",
        "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/hosts/pro.txt"
    )
    private val SKIP = setOf(
        "localhost", "localhost.localdomain", "local", "broadcasthost",
        "ip6-localhost", "ip6-loopback", "0.0.0.0"
    )

    /** Понимает и строки hosts ("0.0.0.0 домен"), и просто домены. */
    fun parseLine(raw: String): String? {
        val line = raw.substringBefore('#').trim()
        if (line.isEmpty()) return null
        val t = line.split(Regex("\\s+"))
        val d = when {
            t.size == 1 -> t[0]
            t[0] == "0.0.0.0" || t[0] == "127.0.0.1" -> t[1]
            else -> return null
        }.lowercase()
        return if ('.' in d && d !in SKIP) d else null
    }

    fun load(ctx: Context): Set<String> {
        val set = HashSet<String>()
        ctx.assets.open("blocklist.txt").bufferedReader().useLines { ls ->
            ls.forEach { parseLine(it)?.let(set::add) }
        }
        val extra = File(ctx.filesDir, "blocklist_extra.txt")
        if (extra.exists()) extra.bufferedReader().useLines { ls ->
            ls.forEach { parseLine(it)?.let(set::add) }
        }
        return set
    }

    /** Скачивает списки. Возвращает число доменов или -1, если ничего не скачалось. */
    fun update(ctx: Context): Int {
        val set = HashSet<String>()
        for (u in URLS) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.inputStream.bufferedReader().useLines { ls ->
                    ls.forEach { parseLine(it)?.let(set::add) }
                }
                c.disconnect()
            } catch (_: Exception) {}
        }
        if (set.isEmpty()) return -1
        File(ctx.filesDir, "blocklist_extra.txt").writeText(set.joinToString("\n"))
        return set.size
    }
}
